public record User(int userId, string name, DateOnly dob);
